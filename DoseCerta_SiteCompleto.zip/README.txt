
📦 Pacote Completo - DOSE CERTA

Este é o site pronto para publicação do portal Dose Certa.
Inclui:
- Página inicial
- Formulário de inscrição
- Painel de administração (Firebase)
- Página de verificação de certificados

👨🏾‍💻 Desenvolvido para: Thiago Silva Santos
🎨 Tema: Preto e Dourado Metálico
🌐 Domínio sugerido: dosecerta.com.br

Para subir o site:
1️⃣ Crie uma conta no Firebase Hosting ou em serviços como Netlify ou Vercel.
2️⃣ Faça upload do conteúdo desta pasta.
3️⃣ Configure o domínio “dosecerta.com.br”.
4️⃣ Substitua as chaves do Firebase no arquivo js/firebase-config.js.

Pronto! Seu portal Dose Certa estará online.
